<?php
	require_once('./lib/nusoap.php');
	$client = new nusoap_client('http://127.0.0.1/nusoap/index.php');
	$result =$client->call( 'hello', array('name' => 'sunlong' ) ); 

	$err = $client->getError();
	if( $err ){
		 echo '<p><b> Error: ' . $err . '</b></p>';
	}else{
		print_r( $result );
	}
?>