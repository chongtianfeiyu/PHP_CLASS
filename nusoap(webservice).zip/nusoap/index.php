<?php

	require_once( "./lib/nusoap.php" );

	$server = new soap_server();
	$server->register('hello');

	function hello( $name ){

		if( !is_string( $name ) ){
			return new soap_fault('Client', '', 'The   first number is invalid');
		} 

		return "hello  : ".$name;
	}


	$HTTP_RAW_POST_DATA = $HTTP_RAW_POST_DATA ? : '';

	$server->service($HTTP_RAW_POST_DATA);
?>