$(function(){
	var uploader = new plupload.Uploader({
		runtimes : 'html5,flash,html4',
		browse_button : 'ajax_upload_attach_button_s1',
		container : 'uploaddiv',
		max_file_size : '30mb',
		multi_selection : false,
		multiple_queues : false,
		url :  'upload.php',
		flash_swf_url : '../js/Moxie.swf',
	});
	uploader.bind('Init', function(up, params) {
		/** alert('runtime=' + params.runtime);* */
	});
	uploader.init();
	
	uploader.bind('FilesAdded', function(up, files) {

		var html = '';
		for ( var i = 0; i < files.length; i++) {
			/** Uploader内部逻辑要用到，不能没有 */
			html += '<div id="' + files[i].id + '">' + files[i].name + ' (' + plupload.formatSize(files[i].size) + ') <b></b></div>';
		}
		$('#fileListDiv').append(html);

		$('#uploadingDiv a[name="attach_title"]').text(files[0].name);
		$('#uploadingDiv').show();

		uploader.start();
	});
	uploader.bind('UploadProgress', function(up, file) {
		if (file.percent < 100) {
			var percent = file.percent + '%';
			$('span[name="percent"]').width(percent);
		} else {
			$('span[name="percent"]').width('100%');
		}
	});
	uploader.bind('FileUploaded', function(up, file, info) {
		/* 返回的json以{开始，以}结束，用正则替换去掉额外字符 */
		var resp = info.response.replace(new RegExp('^[^\{]+|[^\}]+$'), '');
		var json = false;
		if (resp != '') {
			try {
				json = JSON.parse(resp);
			} catch (e) {
				json = false
			}
		}
		if(up.runtime=='flash'){
			if (json.status) {
				alert('上传成功');
				// window.location.reload();
				$('#uploadingDiv').hide();
				var info = json.info;
				attach_upload_success_s1(info[0]);

			} else {
				alert('上传失败');
			}
			return;
		}
		
		if (typeof json == 'object' && json.status) {
			Success( {
				message : '上传成功',
				handler : function(e) {
					// window.location.reload();
					$('#uploadingDiv').hide();
					var info = json.info;
					attach_upload_success_s1(info[0]);
				}
			});
		} else {
			Error( {
				message : '上传失败',
				handler : function(e) {
					// window.location.reload();
					$('#uploadingDiv').hide();
				}
			});
		}
	});
	uploader.bind('Error', function(up, obj) {
		if (obj.code == -600) {
			ymPrompt.errorInfo('上传文件过大，请上传在30M以内的文件');
		}
	});
	
})
