$(function(){
	var uploader = new plupload.Uploader({
		runtimes : 'html5,flash,html4',
		max_file_size : '30mb',
		browse_button : 'ajax_upload_attach_button_s1',  //上传按钮的ID
		container : document.getElementById('uploaddiv'), //这个是容器的地址(父级div)小
		multi_selection : false,	
		multiple_queues : false,
		url : 'upload.php',  //服务器的地址(处理上传的PHP文件)
		flash_swf_url : '../js/Moxie.swf',  //swf文件地址
		filters : [ {
			title : "网页文件",
			extensions : "htm,html"
		} ],
	});
	//文件添加时，在文件中显示要上传的文件列表
	uploader.bind('FilesAdded', function(up, files) {
		for ( var i = 0; i < files.length; i++) {
			html += '<div id="' + files[i].id + '">' + files[i].name + ' (' + plupload.formatSize(files[i].size) + ') <b></b></div>';	
		}
		$('#filelist').append(html);
		
		alert(html);
	});
	
	uploader.init();
})	
	
	
		
	

