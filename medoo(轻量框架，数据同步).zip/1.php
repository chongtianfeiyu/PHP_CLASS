<?php
	
	/**
     * User: lmz
     * Date: 14-01-07
     * Time: 上午10:42
     */
	header ( "Content-Type: text/html; charset=utf-8" );
	error_reporting (E_ALL);
	set_time_limit(0);
	date_default_timezone_set ( "Asia/chongqing" );
	require "medoo.class.php";
	$config = array (
			'server' => '127.0.0.1',
			'database_type' => 'mysql',
			'username' => 'root',
			'password' => 'root',
			'database_name' => 'sinosig',
			'charset' => 'utf8' 
	);
	
	$database = new medoo ($config);
	
	
	$_type = $database->select("dede_arctype",array("*"),array("id"=>2226));
	//print_r($_type);

	
	$_data = $database->select("content",array("*"));
	
	echo "<pre>";
	print_r($_data);
	echo "</pre>";
	exit;
	$last_user_id = $database->insert("dede_arctiny", array(
		"typeid" => "2226",
		"typeid2" => "0",
		"arcrank" => 0,
		"channel" => 1,
		"senddate" => time(),
		"sortrank" => time(),		
		"mid" => 0	
	));
	
	echo $last_user_id;
	if($last_user_id > 0){
		
	}
	exit;
			$dede_arctiny = "INSERT INTO `dede_arctiny` VALUES ('{$_data['id']}', '{$_Location_data['id']}', '0', '0', '1', '{$_data['time']}', '{$_data['time']}', '1')";
			
			$dede_archives = "INSERT INTO `dede_archives` VALUES ('{$_data['id']}', '{$_Location_data['id']}', '0', '{$_data['time']}', 'p', '-1', '1', '0', '{$_data['click']}', '0', '{$_data['name']}', '', '', '管理�?', '管理�?', '{$_pic}', '{$_data['time']}', '{$_data['time']}', '1', '', '0', '0', '0', '0', '0', '0', '', '', '1', '0', '0', '2')";
			
			
			
			$_flag_1 = $database->select("dede_archives",array("id"),array("id"=>$_data['id']));
			$_flag_2 = $database->select("dede_arctiny",array("id"),array("id"=>$_data['id']));
			$_flag_3 = $database->select("dede_addonarticle",array("aid"),array("aid"=>$_data['id']));
			if(empty($_flag_1) && empty($_flag_2) && empty($_flag_3)){
				$database->query($dede_arctiny);
				$database->query($dede_archives);
				$database->query($dede_addonarticle);
				echo $k.' '.$_data['id'];
				echo '<br/>';
				echo $dede_arctiny;
				echo '<br/>';
				echo $dede_archives;
				echo '<br/>';
				echo $dede_addonarticle;
				echo "<hr/>";
			}