<?php
	require_once("../lib/nusoap.php"); 
	
	//传递参数的形式
	function hello($qq) { 
		if($qq){
			return 'Hello'.$qq;
		}else {
			return 'none';
		}
	} 
	$soap = new soap_server; 
	$soap->register('hello'); 
	$soap->service($HTTP_RAW_POST_DATA);
?>