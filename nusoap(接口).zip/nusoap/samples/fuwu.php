<?php

require_once('../lib/nusoap.php');

$client = new nusoap_client('http://localhost:8080/nusoap/fuwu/fuwu.php');   //请求的地址
//需要像HELLO方法传递的参数
$params = array(
    'qq'         => '1644894524',
);
$str = $client->call('hello',$params);
if (!$err=$client->getError()) {
    echo " 程序返回 :",htmlentities($str,ENT_QUOTES);
} else { 
    echo " 错误 :",htmlentities($err,ENT_QUOTES);
}
?>